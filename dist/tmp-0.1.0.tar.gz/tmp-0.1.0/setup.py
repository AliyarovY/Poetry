# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['tmp']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['somecommand = tmp.main:main']}

setup_kwargs = {
    'name': 'tmp',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': '--',
    'author_email': 'yaliyarov@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
